
# Custom Designs LA Website

This repo powers the Custom Designs LA website with Netlify + Netlify CMS.

## Editing the Site
1. Log in to `/admin` on your site.
2. Make edits (text, pricing, images).
3. Netlify CMS will commit changes here on GitHub.
4. Netlify redeploys automatically.

## Folders
- `index.html` → homepage
- `assets/images/` → images & logo
- `collections/` → product entries (rings, charms, pendants, bracelets)
- `admin/config.yml` → Netlify CMS config

## Setup Notes
- Replace `YOUR_GITHUB_USERNAME/customdesignsla-site` in `admin/config.yml` with your actual repo path.
